javac -sourcepath src -d out src/*.java
cd out
java personaltax.Presentation
